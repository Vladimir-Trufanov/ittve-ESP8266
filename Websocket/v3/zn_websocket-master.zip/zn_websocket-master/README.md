# zn_websocket
Простой echo WebSocket сервер на PHP. Для работы необходим модуль php «sockets» (http://php.net/sockets).

Запуск
$ php proc.php